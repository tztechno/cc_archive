git init
git remote add origin https://github.com/tztechno/vercel_autotrace_map.git
git pull origin master 

git add .
git commit -m "2024-08-29"
git push -u origin master
git push -f origin master