git add .
git commit -m "2024-09-06"
git push -u origin master