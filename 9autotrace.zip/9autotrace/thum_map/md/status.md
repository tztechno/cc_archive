```

2024-09-06 14:00
方針転換
localにphotosを置く
localでサムネイル作成と位置情報、時刻を行う
localでindex地図を作成

```